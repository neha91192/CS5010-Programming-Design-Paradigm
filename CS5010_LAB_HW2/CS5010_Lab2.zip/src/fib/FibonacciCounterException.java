package fib;

/**
 * Custom Exception class for FibonacciCounter Interface.
 */
public class FibonacciCounterException extends Exception {
  /**
   * Exception message of type {@link String}.
   */
  private String message;

  /**
   * Initialises message pertaining to this exception.
   *
   * @param message of type {@link String} containing exception details.
   */
  public FibonacciCounterException(String message) {
    this.message = message;
  }

  /**
   * Returns Exception message details.
   *
   * @return message of type {@link String} containing exception details.
   */
  public String getMessage() {
    return message;
  }

}
