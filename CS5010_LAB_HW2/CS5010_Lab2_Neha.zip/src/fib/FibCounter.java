package fib;

/**
 * <p>Implementation class for {@link FibonacciCounter}. It implements four methods -
 * incrementCount, decrementCount, getCount, getFibonacciNumber.</p>
 *
 * @author nehashukla
 */
public class FibCounter implements FibonacciCounter {
  private int count;
  private int fibonacciNumber;
  private int first = 0;
  private int second = 1;
  private int third = 0;
  private static int MAX_COUNT = 47;
  private static int MIN_COUNT = 1;

  /**
   * Default Constructor for FibCounter implementation class. The default value for count is 1 and
   * fibonacciNumber is 0.
   */
  public FibCounter() {
    this.count = 1;
    this.fibonacciNumber = 0;
  }

  /**
   * <p>Increments the count for this FibonacciCounter object. While incrementing the count, it
   * also calculates the next fibonacci number by calling findNextFibonacciNumber(). If this
   * operation is successful,the count will be incremented and the updated values will be returned
   * in FibonacciCounter object</p>
   *
   * @return FibonacciCounter object containing the updated count.
   * @throws java.lang.Exception in case the counter has reached the maximum count value.
   */
  @Override
  public FibonacciCounter incrementCount() throws Exception {
    findNextFibonacciNumber();
    this.count++;
    return this;
  }

  /**
   * <p>Decrements the count for this FibonacciCounter object. While decrementing the count, it
   * also calculates the previous fibonacci number by calling findPreviousFibonacciNumber(). If this
   * operation is successful, the count will be decremented and the updated values will be returned
   * in FibonacciCounter object</p>
   *
   * @return FibonacciCounter object containing the updated count.
   * @throws java.lang.Exception in case the counter has reached the minimum count value.
   */
  @Override
  public FibonacciCounter decrementCount() throws Exception {
    findPreviousFibonacciNumber();
    this.count--;
    return this;
  }

  /**
   * Returns the current counter value.
   *
   * @return count of type integer.
   */
  @Override
  public int getCount() {
    return this.count;
  }

  /**
   * Returns the Fibonacci Number for the current count. This value is pre-calculated on every
   * decrement or increment count call.
   *
   * @return fibonacci number for current counter of type integer.
   */
  @Override
  public int getFibonacciNumber() {
    return this.fibonacciNumber;
  }

  /**
   * Calculates the next fibonacci number when the counter needs to be incremented. It first finds
   * fibonacci number for the incremented count by maintaining two pointers derived from previous
   * two fibonacci numbers and updates fibonacci number value for the incremented count.
   */
  private void findNextFibonacciNumber() throws Exception {
    if (this.count < MAX_COUNT) {
      if (this.count == 2) {
        this.fibonacciNumber = 1;
      } else {
        this.fibonacciNumber = this.first + this.second;
        this.third = this.first;
        this.first = this.second;
        this.second = this.fibonacciNumber;
      }
    } else {
      throw new Exception("Current count has reached maximum the maximum limit");
    }

  }

  /**
   * Calculates the previous fibonacci number before counter is decremented. It first finds the
   * fibonacci number for decremented count by simply taking the value stored in the previous
   * pointer and then updates the fibonacci number value for the decremented count. To move all the
   * pointers one step back, it uses third pointer to update references.
   */
  private void findPreviousFibonacciNumber() throws Exception {
    if (this.count > MIN_COUNT) {
      if (this.count == 2) {
        this.fibonacciNumber = 0;
      } else {
        this.fibonacciNumber = this.first;
        int temp = this.third;
        this.third = this.first - this.third;
        this.second = this.first;
        this.first = temp;
      }
    } else {
      throw new Exception("Current count has reached the minimum limit");
    }
  }
}
