import org.junit.BeforeClass;
import org.junit.Test;

import decoder.Decoder;
import decoder.DecoderImpl;

import static org.junit.Assert.assertEquals;

public class DecoderTest {

  private static Decoder decoder;
  private static Decoder decoder2;
  private static Decoder decoder3;
  private static Decoder decoder4;

  @BeforeClass
  public static void setUp() {
    decoder = new DecoderImpl("01");
    decoder2 = new DecoderImpl("01");
    decoder3 = new DecoderImpl("012");
    decoder4 = new DecoderImpl("01");
    initializeDecoder();
    initializeDecoder4();

  }
  private static void initializeDecoder(){
    decoder.addCode('b', "00");
    decoder.addCode('c', "011");
    decoder.addCode('a', "100");
    decoder.addCode('e', "101");
    decoder.addCode('d', "11");
    decoder.addCode('\t', "010");
  }
  private static void initializeDecoder4(){
    decoder4.addCode('c', "00");
    decoder4.addCode('b', "011");
    decoder4.addCode('a', "100");
    decoder4.addCode('d', "101");
    decoder4.addCode('e', "11");
  }

  /**
   * Checks for the case where answer is right.
   */
  @Test
  public void testAddCode1() {
    decoder4.addCode('b', "00");
    decoder4.addCode('c', "011");
    decoder4.addCode('a', "100");
    decoder4.addCode('e', "101");
    decoder4.addCode('d', "11");

  }

  public void testAddCode2(){
    decoder3.addCode('a', "01");
    decoder3.addCode('b', "201");
    decoder3.addCode('c', "021");
    decoder3.addCode('e', "102");
    decoder3.addCode('d', "00");
  }

  /**
   * Checks for the case where answer is right.
   */
  @Test(expected = IllegalStateException.class)
  public void testAddCodeInvalidSymbols() {
    decoder.addCode('a', "03");
    decoder.addCode('b', "214");
    decoder.addCode('c', "332");
    decoder.addCode('e', "103");
    decoder.addCode('d', "32");

  }

  /**
   * Checks for the case where answer is right.
   */
  @Test
  public void testDecode() {
    String val = decoder.decode("10010100");
    System.out.println(val);
    assertEquals("aeb", val);
    String val2 = decoder.decode("00101110100010011");
    System.out.println(val2);
    assertEquals("bed	bad", val2);

  }
  /**
   * Checks for the case where answer is right.
   */
  @Test
  public void testDecode2() {
    String val = decoder2.decode("10010100");
    System.out.println(val);
    assertEquals("", val);

  }
  /**
   * Checks for the case where answer is right.
   */
  @Test(expected = IllegalStateException.class)
  public void testDecodeInvalid() {
    //gives value upto decoding value is found
    assertEquals("bed	bad", decoder.decode("00101110100010011"));

  }


  /**
   * Checks for the case where answer is right.
   */
  @Test
  public void testAllCodes() {
    String val = decoder.allCodes();
    System.out.println(val);

  }

  /**
   * Checks for the case where code is complete for binary values of codes.
   */
  @Test
  public void testisCodeComplete1() {
    Boolean result = decoder.isCodeComplete();
    assertEquals(true, result);

  }

  /**
   * Checks for the case where code is complete for n-ary values of codes.
   */
  @Test
  public void testisCodeComplete2() {
    Boolean result = decoder.isCodeComplete();
    assertEquals(true, result);

  }

  /**
   * Checks for the case where code is incomplete for any values of codes.
   */
  @Test
  public void testisCodeComplete3() {
    Boolean result = decoder4.isCodeComplete();
    assertEquals(false, result);

  }

}
