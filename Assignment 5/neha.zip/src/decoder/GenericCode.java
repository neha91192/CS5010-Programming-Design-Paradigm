package decoder;

import java.util.Map;
import java.util.Stack;

public class GenericCode implements Code {
  /**
   * String character which is the character symbol derived from list of unique codes.
   */
  protected Character symbol;

  private static Stack<Character> path = new Stack<>();

  GenericCode(Character symbol){
    this.symbol = symbol;
  }
  /**
   * Assign calling node as current object. iterate over all the characters in the code and traverse
   * till the point current reaches second last node. Append new character of type {@link
   * CharacterSymbol} to the end as leaf node.
   */
  @Override
  public void addCode(Code characterSymbol, String code) throws IllegalStateException {
  //if it is the last code to be added, add character type code.
      if(code.length()==1){
        this.addCharacterNode(code.charAt(0), characterSymbol);
      } else {
        //if it is the transition node that needs to be added
        if(!this.getChildrenNodes().containsKey(code.charAt(0))){
          this.addTransitionNode(code.charAt(0));
        }
        this.getChildrenNodes().get(code.charAt(0)).addCode(characterSymbol,code.substring(1));
      }
    }

  /**
   *
   * @param message
   * @return
   * @throws IllegalStateException
   */
  @Override
  public String decode(String message) throws IllegalStateException {
    StringBuilder sb = new StringBuilder("");
    GenericCode current = this;
    for (Character character : message.toCharArray()) {
      if(!current.getChildrenNodes().isEmpty()){
        current = (GenericCode)current.getChildrenNodes().get(character);
        if(current.isCharacterSymbol()){
          sb.append(current.getSymbol());
          current = this;
        }
      }
    }
    return sb.toString();
  }

  /**
   *
   * @return
   * If the Code is of type
   * Code Symbol then iterate through its Childrens by calling the same method
   * Character symbol then print the Character symbol and the string passed and return.
   */
  public String allCodes() {
    StringBuilder sb = new StringBuilder("");
    if(this.isCharacterSymbol()){
      sb.append(this.getSymbol());
      sb.append(":");
      for(Character c: path){
        sb.append(c);
      }
      sb.append("\n");
      path.pop();
      return sb.toString();
    }
    for(Character code: this.getChildrenNodes().keySet()){
      //append path here
      path.add(code);
      sb.append(this.getChildrenNodes().get(code).allCodes());
    }
    if(!path.isEmpty()){
      path.pop();
    }
    return sb.toString();
  }

  @Override
  public boolean isCodeComplete() {
   return false;
  }

  @Override
  public Character getSymbol() {
    return this.symbol;
  }

  protected boolean isCharacterSymbol(){
    return false;
  }
  protected boolean isCodeSymbol(){
    return false;
  }

  protected void addCharacterNode(Character character, Code code) {

  }

  protected void addTransitionNode(Character character) {

  }

  protected Map<Character, Code> getChildrenNodes(){
    return null;
  }



}
