package decoder;

import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class CodeSymbol extends GenericCode {
  /**
   * List of codes that are children of the current code. The possible number of children at each
   * level would be the total values defined in {@link CodeValues}.
   */
  private Map<Character, Code> children;

  private String codingSymbols;

  CodeSymbol(Character symbol, String codingSymbols){
    super(symbol);
    this.codingSymbols = codingSymbols;
    children = new HashMap<>();
  }



  @Override
  protected boolean isCharacterSymbol(){
    return false;
  }


  @Override
  protected boolean isCodeSymbol(){
    return true;
  }

  @Override
  protected void addCharacterNode(Character character, Code code) {
    this.children.put(character,code);
  }

  @Override
  protected void addTransitionNode(Character character) {
    this.children.put(character, new CodeSymbol(character, this.codingSymbols));
  }
  @Override
  protected Map<Character, Code> getChildrenNodes(){
    return this.children;
  }

  @Override
  public boolean isCodeComplete() {
    if(this.isCharacterSymbol()) {
      return true;
    }
    boolean result = this.getChildrenNodes().size() == codingSymbols.length();
    if(result) {
      for(Character child : this.getChildrenNodes().keySet()){
        result = this.getChildrenNodes().get(child).isCodeComplete();
        if(!result){
          break;
        }
      }
    }
    return result;
  }

  @Override
  public Character getSymbol() {
    return this.symbol;
  }

}
