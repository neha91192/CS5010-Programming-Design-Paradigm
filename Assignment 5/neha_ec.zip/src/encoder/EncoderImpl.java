package encoder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeMap;

public class EncoderImpl implements Encoder {

  private String fileContent;

  private TreeMap<String, Integer> frequencyTable;
  private Map<String, Integer> codingTable;

  PriorityQueue<Symbol> queue;

  public EncoderImpl() {
    fileContent = "(Taken from wikipedia)\n" +
            "Grace Brewster Murray Hopper (née Murray; December 9, 1906 – January 1, 1992)" +
            " was an American computer scientist and United States Navy rear admiral.[1] " +
            "One of the first programmers of the Harvard Mark I computer, she was a pioneer " +
            "of computer programming who invented one of the first compiler related tools. " +
            "She popularized the idea of machine-independent programming languages," +
            " which led to the development of COBOL, an early high-level programming " +
            "language still in use today.\n" +
            "Hopper attempted to enlist in the Navy during World War II but was rejected " +
            "because she was 34 years old. She instead joined the Navy Reserves. Hopper " +
            "began her computing career in 1944 when she worked on the Harvard Mark I " +
            "team led by Howard H. Aiken. In 1949, she joined the Eckert–Mauchly Computer " +
            "Corporation and was part of the team that developed the UNIVAC I computer. " +
            "At Eckert–Mauchly she began developing the compiler. She believed that a " +
            "programming language based on English was possible. Her compiler converted " +
            "English terms into machine code understood by computers. By 1952, Hopper had " +
            "finished her program linker (originally called a compiler), which was written " +
            "for the A-0 System.";
    frequencyTable = new TreeMap<>();
    codingTable = new HashMap<>();
  }

  //read file
  public void readSource() {

    try {
      File file = new File("D:\\NeH\\A5\\test\\DecoderTest");
      FileReader fr = null;
      FileReader reader = new FileReader("passage.txt");
      BufferedReader bufferedReader = new BufferedReader(reader);
      String line = null;
      while ((line = bufferedReader.readLine()) != null) {
        System.out.println(line);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  //create frequency table
  public void setUpFrequencyTable(String fileContent){
    int frequency;
    for(int i=0; i<fileContent.length();i++) {
      frequency = 0;
      String symbol = Character.toString(fileContent.charAt(i));
      if (frequencyTable.containsKey(symbol)) {
        frequency = frequencyTable.get(symbol);
      }
      frequencyTable.put(symbol, ++frequency);
    }
  }


  //initialize coding table
  public void setUpCodingTable(Map<String, Integer> frequencyTable){
    for(String key: frequencyTable.keySet()){
      codingTable.put(key, 0);
    }
  }

  //initialize queue
  public void initializeQueue(Map<String, Integer> frequencyTable){
    queue =  new PriorityQueue<>(new SymbolComparator());
    for(String key: frequencyTable.keySet()) {
      Symbol symbol = new Symbol(key, frequencyTable.get(key));
      queue.add(symbol);
    }
  }






}
