import org.junit.BeforeClass;
import org.junit.Test;

import decoder.Decoder;
import decoder.DecoderImpl;

import static org.junit.Assert.assertEquals;

/**
 * Test class for {@link Decoder}.
 */
public class DecoderTest {

  private static Decoder decoder1;
  private static Decoder decoder2;
  private static Decoder decoder3;
  private static Decoder decoder4;
  private static Decoder decoder5;

  /**
   * Sets up the initial values for decoder.
   */
  @BeforeClass
  public static void setUp() {
    decoder1 = new DecoderImpl("01");
    decoder2 = new DecoderImpl("01");
    decoder3 = new DecoderImpl("012");
    decoder4 = new DecoderImpl("01");
    decoder5 = new DecoderImpl("01");
    initializeDecoder();
    initializeDecoder4();

  }

  /**
   * Initialises decoder values for complete tree.
   */
  private static void initializeDecoder(){
    decoder1.addCode('b', "00");
    decoder1.addCode('c', "011");
    decoder1.addCode('a', "100");
    decoder1.addCode('e', "101");
    decoder1.addCode('d', "11");
    decoder1.addCode('\t', "010");
  }
  /**
   * Initialises decoder values for incomplete tree.
   */
  private static void initializeDecoder4(){
    decoder4.addCode('c', "00");
    decoder4.addCode('b', "011");
    decoder4.addCode('a', "100");
    decoder4.addCode('d', "101");
    decoder4.addCode('e', "11");
  }

  /**
   * Checks for the add code condition.
   */
  @Test
  public void testAddCode1() {
    decoder5.addCode('b', "00");
    decoder5.addCode('c', "011");
    decoder5.addCode('a', "100");
    decoder5.addCode('e', "101");
    decoder5.addCode('d', "11");
  }

  /**
   * Checks for the add code condition for larger coding symbol values.
   */
  @Test
  public void testAddCode2(){
    decoder3.addCode('a', "01");
    decoder3.addCode('b', "201");
    decoder3.addCode('c', "021");
    decoder3.addCode('e', "102");
    decoder3.addCode('d', "00");
  }

  /**
   * Checks for the case where invalid code is added.
   */
  @Test(expected = IllegalStateException.class)
  public void testAddCodeInvalidSymbols() {
    decoder1.addCode('a', "03");
    decoder1.addCode('b', "214");
    decoder1.addCode('c', "332");
    decoder1.addCode('e', "103");
    decoder1.addCode('d', "32");

  }

  /**
   * Checks for the case where decoding is successful.
   */
  @Test
  public void testDecode() {
    String val = decoder1.decode("10010100");
    System.out.println(val);
    assertEquals("aeb", val);
    String val2 = decoder1.decode("00101110100010011");
    System.out.println(val2);
    assertEquals("bed	bad", val2);

  }
  /**
   * Checks for the case where decoding is successful for empty tree.
   */
  @Test(expected = IllegalStateException.class)
  public void testDecode2() {
    String val = decoder2.decode("10010100");
    System.out.println(val);
    assertEquals("", val);

  }
  /**
   * Checks for the case where answer is right.
   */
  @Test(expected = IllegalStateException.class)
  public void testDecodeInvalid() {
    //gives value upto decoding value is found
    System.out.println( decoder1.decode("0010111010001001101"));
    //assertEquals("bed	bad", decoder1.decode("00101110100010011"));

  }


  /**
   * Checks for the case where answer is right.
   */
  @Test
  public void testAllCodes() {
    String val = decoder1.allCodes();
    System.out.println(val);

  }

  /**
   * Checks for the case where code is complete for binary values of codes.
   */
  @Test
  public void testIsCodeComplete1() {
    Boolean result = decoder1.isCodeComplete();
    assertEquals(true, result);

  }

  /**
   * Checks for the case where code is complete for n-ary values of codes.
   */
  @Test
  public void testIsCodeComplete2() {
    Boolean result = decoder1.isCodeComplete();
    assertEquals(true, result);

  }

  /**
   * Checks for the case where code is incomplete for any values of codes.
   */
  @Test
  public void testIsCodeComplete3() {
    Boolean result = decoder4.isCodeComplete();
    assertEquals(false, result);

  }

}
