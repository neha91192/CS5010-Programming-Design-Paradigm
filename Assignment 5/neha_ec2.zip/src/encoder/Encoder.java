package encoder;

import java.util.Map;

public interface Encoder {
  void readSource();

  void setUpFrequencyTable(String content);

  void setUpCodingTable(Map<String, Integer> frequencyTable);

  void initializeQueue(Map<String, Integer> frequencyTable);
}
