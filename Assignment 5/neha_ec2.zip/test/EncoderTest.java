import org.junit.Before;
import org.junit.Test;

import encoder.Encoder;
import encoder.EncoderImpl;


public class EncoderTest {
  private  Encoder encoder;
  @Before
  public  void setUp() {
    encoder = new EncoderImpl();
  }

  @Test
  public void testReadSource() {
    encoder.readSource();
  }

  @Test
  public void testCreateFrequencyTable() {
    String value = "HelloWorld";
    encoder.setUpFrequencyTable(value);

  }
}

