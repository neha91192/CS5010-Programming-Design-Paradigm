package decoder;

import java.util.HashSet;
import java.util.Set;

public class DecoderImpl implements Decoder {

  private Code root;

  private Set<Character> codeSymbols;

  public DecoderImpl(String code){
    root = new CodeSymbol('0',code);
    codeSymbols = new HashSet<>();
    for(Character c :code.toCharArray()) {
      codeSymbols.add(c);
    }
  }

  @Override
  public void addCode(Character symbol, String code) throws IllegalStateException {
    Code character = new CharacterSymbol(symbol);
    if(containsValidSymbol(code)) {
      root.addCode(character, code);
    } else {
      throw new IllegalStateException("Cannot support the given code values");
    }


  }

  @Override
  public String decode(String message) throws IllegalStateException {
    return root.decode(message);
  }

  @Override
  public String allCodes() {
    return root.allCodes();
  }



  @Override
  public boolean isCodeComplete() {
    return root.isCodeComplete();
  }

  /**
   *
   * @param symbols
   * @return
   */
  private boolean containsValidSymbol(String symbols){
    for(Character c: symbols.toCharArray()){
      if(!codeSymbols.contains(c)) {
        return false;
      }
    }
    return true;
  }

}
