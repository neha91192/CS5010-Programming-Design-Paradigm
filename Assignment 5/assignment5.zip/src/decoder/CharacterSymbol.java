package decoder;

public class CharacterSymbol extends GenericCode {

  CharacterSymbol(Character symbol) {
    super(symbol);
  }

  @Override
  protected boolean isCharacterSymbol() {
    return true;
  }

  @Override
  protected boolean isCodeSymbol() {
    return false;
  }

  @Override
  public Character getSymbol() {
    return this.symbol;
  }

  @Override
  public boolean isCodeComplete() {
    return true;
  }
}
