package decoder;

public interface Code {
  /**
   *
   * @param characterCode
   * @param code
   * @throws IllegalStateException
   */
  void addCode(Code characterCode, String code) throws IllegalStateException;

  /**
   *
   * @param message
   * @return
   * @throws IllegalStateException
   */
  String decode(String message) throws IllegalStateException;

  boolean isCodeComplete();

  String allCodes();

  Character getSymbol();

}
