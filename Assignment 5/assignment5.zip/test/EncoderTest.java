import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import encoder.Encoder;
import encoder.EncoderImpl;
import encoder.Symbol;


public class EncoderTest {
  private  Encoder encoder;
  @Before
  public  void setUp() {
    encoder = new EncoderImpl();
  }

  @Test
  public void testReadSource() {
    encoder.readSource();
  }

  @Test
  public void testCreateFrequencyTable() {
    String value = "HelloWorld";
    Map<String, Symbol> ip = encoder.setUpFrequencyTable(value);
    for(String a : ip.keySet())
      System.out.println(a + " : " + ip.get(a));
  }
}

