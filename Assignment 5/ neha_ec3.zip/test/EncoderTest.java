import org.junit.Before;
import org.junit.Test;

import encoder.Encoder;
import encoder.EncoderImpl;

/**
 * Test class for {@link Encoder}.
 */
public class EncoderTest {
  /**
   * Encoder for calculating binary coding values.
   */
  private  Encoder encoder1;
  /**
   * Encoder for calculating hex coding values.
   */
  private  Encoder encoder2;
  @Before
  public  void setUp() {
    encoder1 = new EncoderImpl("01");
    encoder2 = new EncoderImpl("0123456789abcdef");
  }

  /**
   * Test for encoding of binary coder.
   */
  @Test
  public void testEncode() {
    String value = encoder1.encode("");
    System.out.println(value);
  }

}

