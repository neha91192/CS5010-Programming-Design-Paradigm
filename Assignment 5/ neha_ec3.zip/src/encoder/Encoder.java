package encoder;

/**
 * Represents encoder interface which gives a base implementation details for any encoder
 * algorithm.
 */
public interface Encoder {
  /**
   * This method takes fileName as input and returns the encoded value in String. The file should be
   * present in the resource folder.
   *
   * @param fileName in String.
   * @return encoded value in String.
   */
  String encode(String fileName);

}
