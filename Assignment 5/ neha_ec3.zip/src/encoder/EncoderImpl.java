package encoder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeMap;

/**
 * Implements Huffman Encoding algorithm to determine shortest encoding for any given plaintext.
 */
public class EncoderImpl implements Encoder {
  private String fileContent;

  private TreeMap<Character, Integer> frequencyTable;
  private Map<Character, String> codingTable;
  private List<Character> codingSymbols;

  private PriorityQueue<Symbol> queue;

  /**
   * Initialises several values required for computing Huffman encoding.
   *
   * @param supportedSymbols Takes coding values supported for Huffman encoder.
   */
  public EncoderImpl(String supportedSymbols) {
    fileContent = "In order to help us determine whether your encoder works correctly, "
            + "please follow these steps";
    frequencyTable = new TreeMap<>();
    codingTable = new HashMap<>();
    codingSymbols = new ArrayList<>();
    for (Character c : supportedSymbols.toCharArray()) {
      if (!codingSymbols.contains(c)) {
        codingSymbols.add(c);
      }
    }
  }

  /**
   * Reads txt file to produce encoding symbols for each characters in the file.
   */
  public void readSource(String fileName) {

    try {
      File file = new File("D:\\NeH\\A5\\test\\DecoderTest");
      FileReader fr = null;
      FileReader reader = new FileReader("passage.txt");
      BufferedReader bufferedReader = new BufferedReader(reader);
      String line = null;
      while ((line = bufferedReader.readLine()) != null) {
        System.out.println(line);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Sets up the frequency table by parsing each character of the file content.
   *
   * @param fileContent in String
   */
  private void setUpFrequencyTable(String fileContent) {
    int frequency;
    for (int i = 0; i < fileContent.length(); i++) {
      frequency = 0;
      Character symbol = fileContent.charAt(i);
      if (frequencyTable.containsKey(symbol)) {
        frequency = frequencyTable.get(symbol);
      }
      frequencyTable.put(symbol, ++frequency);
    }
  }


  /**
   * Builds up the table which stores character and the encoded symbol values of that character.
   */
  private void setUpCodingTable() {
    for (Character key : frequencyTable.keySet()) {
      codingTable.put(key, "");
    }
  }

  /**
   * Pre-populates queue required for the generating huffman codes.
   */
  private void initializeQueue() {
    queue = new PriorityQueue<Symbol>(new SymbolComparator());
    for (Character key : frequencyTable.keySet()) {
      Symbol symbol = new Symbol(Character.toString(key), frequencyTable.get(key));
      queue.add(symbol);
    }
  }

  /**
   * For each nth element in coding symbol, it pops n items from the queue and then add prefix of
   * the coding symbol to the encoding values. Updates codingTable which maintains record of each
   * character and encoding values. At the end, it concatenates all the symbol string encountered
   * with their combined frequency, and put them back in to the queue. Since the queue maintains its
   * ordering, we don't have to handle any ordering if a new element has been added to the queue.
   */
  private void processQueue() {
    int frequency = 0;
    StringBuilder sb = new StringBuilder();

    for (Character code : codingSymbols) {
      Symbol symbol = queue.poll();
      if (symbol != null) {
        sb.append(symbol.getValue());
        frequency = frequency + symbol.getFrequency();
        for (Character c : symbol.getValue().toCharArray()) {
          String value = codingTable.get(c);
          value = code + value;
          codingTable.put(c, value);
        }
      }
    }
    Symbol newSymbol = new Symbol(sb.toString(), frequency);
    queue.add(newSymbol);
  }

  /**
   * Parses each character in the file content and returns the encoded value in String.
   *
   * @return encoded value in String.
   */
  private String generateCode() {
    StringBuilder sb = new StringBuilder();
    for (Character c : fileContent.toCharArray()) {
      if (codingTable.containsKey(c)) {
        sb.append(codingTable.get(c));
      }
    }
    return sb.toString();
  }

  /**
   * Takes file name as input parameter and processes each character in the file to perform Huffman
   * Encoding.
   */
  @Override
  public String encode(String fileName) {
    //readSource(fileName);
    setUpFrequencyTable(fileContent);
    setUpCodingTable();
    initializeQueue();
    processQueue();
    return generateCode();
  }
}
