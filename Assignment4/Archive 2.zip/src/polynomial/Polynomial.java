package polynomial;

/**
 * <p>This interface represents a Polynomial which is made up of number of terms. A polynomial
 * contains degree, which is the highest power of variable in the term. As mentioned before, it also
 * has related terms which themselves contain coefficient and power.</p>
 * <p>For this interface, we are only considering polynomials whose powers are positive and
 * coefficient values are integral numbers.</p>
 * <p>Any two polynomials are supposed to be equal if they contain exactly the same set of
 * terms.</p>
 * <p>There are set of behaviors which this polynomial interface are expected to
 * follow:</p>
 * <ul>
 * <li><strong>addTerm: </strong> Should be able to add a new term to the existing polynomial.</li>
 * <li><strong>getDegree: </strong> Should return the highest power out of all the terms in the
 * polynomial.</li>
 * <li><strong>getCoefficient: </strong>Given a power, polynomial interface should return the
 * degree and coefficient corresponding to that power.</li>
 * <li><strong>evaluate: </strong> Should be able to evaluate the value of the polynomial if any
 * value is substituted in all the variables of the polynomial.</li>
 * <li><strong>add: </strong>Merges two polynomial to make it as a single polynomial.</li>
 * <li><strong>derivative: </strong>Finds out the derivative of given polynomial and returns a new
 * polynomial object.</li>
 * </ul>
 */
public interface Polynomial {
  /**
   * Search for the place where new term needs to be inserted and add accordingly. Both the
   * parameters - coefficient and power should be whole number.
   *
   * @param coefficient contains coefficient of the term.
   * @param power       contains power of the term.
   * @throws IllegalArgumentException in case the term is invalid.
   */
  void addTerm(Integer coefficient, Integer power) throws IllegalArgumentException;

  /**
   * Returns degree of this polynomial. Degree of any polynomial is the highest power of the
   * variable in a term.
   *
   * @return Integer containing degree of polynomial.
   */
  int getDegree();

  /**
   * Fetches the term corresponding to the given power.
   *
   * @return term containing coefficient and power.
   */
  int getCoefficient(Integer power);

  /**
   * Evaluates value of the polynomial for the given value.
   *
   * @param value of type Double.
   * @return value of type Double.
   */
  Double evaluate(Double value);

  /**
   * Takes polynomial as an input and returns the added polynomial.
   *
   * @param polynomial of type Polynomial which needs to be added to the current polynomial.
   */
  Polynomial add(Polynomial polynomial);

  /**
   * Calculates derivative of polynomial and return the derived polynomial.
   *
   * @return polynomial of type Polynomial.
   */
  Polynomial derivative();
}
