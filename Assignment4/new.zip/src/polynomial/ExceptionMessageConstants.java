package polynomial;

public class ExceptionMessageConstants {
}
