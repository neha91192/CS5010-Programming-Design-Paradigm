package polynomial;

import java.util.InputMismatchException;
import java.util.Objects;
import java.util.Scanner;

/**
 * This is an implementation class for {@link Polynomial}. Polynomial should store only non-zero
 * coefficient terms.
 */
public class PolynomialImpl implements Polynomial, Comparable {

  private PolynomialADTNode head;

  /**
   * Constructs polynomial with no coefficients.
   */
  public PolynomialImpl() {
    head = new PolynomialADTEmptyNode();
  }

  /**
   * Takes polynomial as String and initialises each term of the polynomial.
   */
  public PolynomialImpl(String polynomial) throws IllegalArgumentException {
    //split each term and initialise polynomial with head as highest degree.
    Scanner scanner = new Scanner(polynomial);
    head = new PolynomialADTEmptyNode();
    while (scanner.hasNext()) {
      try{
        Term term = parseTerm(scanner.next());
        head = head.addTerm(term);
      } catch (InputMismatchException e) {
        throw  new IllegalArgumentException("Invalid polynomial String");
      }
    }
  }

  /**
   * Constructs polynomial with no coefficients.
   */
  private PolynomialImpl(PolynomialADTNode head) {
    this.head = head;
  }

  @Override
  public void addTerm(Integer coefficient, Integer power) throws IllegalArgumentException {
    if (power < 0) {
      throw new IllegalArgumentException("Negative powers are not allowed");
    }
    Term newTerm = new Term(coefficient, power);
    head = head.addTerm(newTerm);
  }

  /**
   *
   * @return
   */
  @Override
  public int getDegree() {
    return this.head.getDegree();
  }

  /**
   *
   * @param power
   * @return
   */
  @Override
  public int getCoefficient(Integer power) {
    return this.head.getCoefficient(power);
  }

  /**
   * @param value of type Double.
   */
  @Override
  public Double evaluate(Double value) {
    return this.head.evaluate(value);
  }

  /**
   * @param polynomial of type Polynomial which needs to be added to the current polynomial.
   */
  @Override
  public Polynomial add(Polynomial polynomial) {
    if(polynomial.toString().substring(0,1).equals("-")) {
      return new PolynomialImpl(this.toString()+" "+polynomial.toString());
    }
    return new PolynomialImpl(this.toString()+" +"+polynomial.toString());
  }

  /**
   *
   * @return
   */
  @Override
  public Polynomial derivative() {
    PolynomialADTNode newHead = this.head.derivative();
    return new PolynomialImpl(newHead);
  }

  /**
   *
   * @return
   */
  @Override
  public String toString() {
    String value = head.toString();
    if (!value.equals("") && value.substring(0, 1).equals("+")) {
      return value.substring(1);
    } else return value;
  }

  /**
   *
   * @param object
   * @return
   */
  @Override
  public int compareTo(Object object) {
    if (object instanceof PolynomialImpl) {
      PolynomialImpl polynomial = (PolynomialImpl) object;
      if(this.evaluate(1.0)>polynomial.evaluate(1.0)) {
        return 1;
      } else if(this.evaluate(1.0)<polynomial.evaluate(1.0)){
        return -1;
      }
      return 0;
    }
    return -1;
  }

  /**
   *
   * @return
   */
  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (!(object instanceof PolynomialImpl)) {
      return false;
    }
    PolynomialImpl polynomialObj = (PolynomialImpl) object;
    return this.head.equals(polynomialObj.head);
  }

  /**
   *
   * @return
   */
  @Override
  public int hashCode() {
    return Objects.hash(head);
  }

  /**
   * Takes term as string and converts into {@link Term}.
   * @param term
   * @return
   */
  private Term parseTerm(String term) throws IllegalArgumentException, InputMismatchException {
    Scanner termScanner = new Scanner(term).useDelimiter("x\\^");
    int coefficient = termScanner.nextInt();
    int power = 0;
    if (termScanner.hasNextInt()) {
      power = termScanner.nextInt();
      if (power < 0) {
        throw new IllegalArgumentException("Powers cannot be negative");
      }
    }
    if(termScanner.hasNext()){
      System.out.println(termScanner.nextInt());
      throw new IllegalArgumentException("Invalid string");
    }
    return new Term(coefficient, power);
  }


}
