package polynomial;


import java.util.Objects;

/**
 *
 */
public class PolynomialADTElementNode implements PolynomialADTNode {

  /**
   * Represents current term of this Polynomial node.
   */
  private Term term;
  /**
   * Represents rest of the terms after this polynomial node.
   */
  private PolynomialADTNode rest;

  /**
   * Constructor for initialising Polynomial Element node.
   *
   * @param term current term of this element node.
   * @param rest list of terms next to this element node.
   */
  PolynomialADTElementNode(Term term, PolynomialADTNode rest) {
    this.term = term;
    this.rest = rest;
  }

  /**
   *
   * @param term
   * @throws IllegalArgumentException
   */
  @Override
  public PolynomialADTNode addTerm(Term term) throws IllegalArgumentException {
    if (this.term.getPower().equals(term.getPower())) {
      //merge two terms with same degree.
      int sum = this.term.getCoefficient() + term.getCoefficient();
      if (sum == 0) {
        return this.rest;
      }
      this.term.setCoefficient(sum);
    } else if (this.term.getPower() > term.getPower()) {
      //search for lower degrees, if new term reaches empty node, add element at the end of the list.
      this.rest = this.rest.addTerm(term);
    } else {
      //add at front
      return new PolynomialADTElementNode(term, this);
    }
    return this;
  }

  /**
   *
   * @return
   */
  @Override
  public Integer getDegree() {
    return this.term.getPower();
  }

  /**
   *
   * @param power
   * @return
   */
  @Override
  public Integer getCoefficient(Integer power) {
    if (this.term.getPower().equals(power)) {
      return this.term.getCoefficient();
    }
    return this.rest.getCoefficient(power);
  }

  /**
   *
   * @param value
   * @return
   */
  @Override
  public Double evaluate(Double value) {
    Double val = this.term.getCoefficient() * Math.pow(this.term.getPower(), value);
    return this.term.getCoefficient() * Math.pow(value, this.term.getPower())
            + this.rest.evaluate(value);
  }

  /**
   *
   * @param polynomial
   * @return
   */
  @Override
  public PolynomialADTNode addPolynomial(PolynomialADTNode polynomial) {
    return null;
  }

  /**
   *
   * @return
   */
  @Override
  public PolynomialADTNode derivative() {
    Term newTerm = new Term(this.term.getCoefficient() * this.term.getPower(),
            this.term.getPower() - 1);
    return new PolynomialADTElementNode(newTerm, this.rest.derivative());
  }

  /**
   *
   * @return
   */
  @Override
  public String toString() {
    if (this.rest instanceof PolynomialADTEmptyNode) {
      return this.term.toString();
    }
    return this.term.toString() + "" + this.rest.toString();
  }

  /**
   *
   * @param polynomialNode
   * @return
   */
  @Override
  public boolean equals(Object polynomialNode) {
    if (this == polynomialNode) {
      return true;
    }
    if (!(polynomialNode instanceof PolynomialADTElementNode)) {
      return false;
    }
    PolynomialADTElementNode elementNode = (PolynomialADTElementNode) polynomialNode;
    return Objects.equals(term, elementNode.term) &&
            Objects.equals(rest, elementNode.rest);
  }

  @Override
  public int hashCode() {
    return Objects.hash(term, rest);
  }
}
