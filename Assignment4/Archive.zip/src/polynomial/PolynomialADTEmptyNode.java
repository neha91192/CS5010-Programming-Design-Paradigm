package polynomial;

import java.util.Objects;
import java.util.function.Function;

/**
 *
 */
public class PolynomialADTEmptyNode implements PolynomialADTNode {
  /**
   * Represents current term of this Polynomial node.
   */
  private Term term;
  /**
   * Represents rest of the terms after this polynomial node.
   */
  private PolynomialADTNode rest;

  PolynomialADTEmptyNode() {
    this.term = new Term(0, 0);
  }

  /**
   *
   * @param term
   * @throws IllegalArgumentException
   */
  @Override
  public PolynomialADTNode addTerm(Term term) throws IllegalArgumentException {
    return new PolynomialADTElementNode(term, new PolynomialADTEmptyNode());
  }

  /**
   *
   * @return
   */
  @Override
  public Integer getDegree() {
    return this.term.getPower();
  }

  /**
   *
   * @param power
   * @return
   */
  @Override
  public Integer getCoefficient(Integer power) {
    return this.term.getCoefficient();
  }

  /**
   *
   * @param value
   * @return
   */
  @Override
  public Double evaluate(Double value) {
    return this.term.getCoefficient()*value;
  }

  /**
   *
   * @param polynomial
   * @return
   */
  @Override
  public PolynomialADTNode addPolynomial(PolynomialADTNode polynomial) {
    return new PolynomialADTEmptyNode();
  }

  /**
   *
   * @return
   */
  @Override
  public PolynomialADTNode derivative() {
    return new PolynomialADTEmptyNode();
  }

  /**
   *
   * @return
   */
  @Override
  public String toString() {
    return String.format("%d", this.term.getCoefficient());
  }

  /**
   *
   * @param polynomialNode
   * @return
   */
  @Override
  public boolean equals(Object polynomialNode) {
    if (this == polynomialNode) {
      return true;
    }
    if (!(polynomialNode instanceof PolynomialADTEmptyNode)) {
      return false;
    }
    PolynomialADTEmptyNode elementNode = (PolynomialADTEmptyNode) polynomialNode;
    return Objects.equals(term, elementNode.term) &&
            Objects.equals(rest, elementNode.rest);
  }

  /**
   *
   * @return
   */
  @Override
  public int hashCode() {
    return Objects.hash(term, rest);
  }
}
