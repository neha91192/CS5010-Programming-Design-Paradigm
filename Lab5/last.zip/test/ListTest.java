import org.junit.Before;
import org.junit.Test;

import java.util.List;

import listadt.ImmutableList;
import listadt.ImmutableListADTImpl;
import listadt.ListADT;
import listadt.ListADTImpl;
import listadt.MutableList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Tests the generic list representation {@link ListADT} interface. Assuming the ListImpl works
 * correctly, it checks for the enhancement made for Immutable list.
 */
public class ListTest {
  private MutableList<Integer> mutable;

  /**
   * Sets the default mutable object.
   */
  @Before
  public void setup() {
    mutable = new ListADTImpl<>();
    mutable.addFront(20);
    mutable.addFront(15);
    mutable.addFront(10);
    mutable.addFront(5);
  }

  /**
   * Demonstrate how your classes should be used.
   */
  @Test
  public void testDemo() {
    //mutable operations
    ListADT<Integer> listADTMutable = new ListADTImpl<>();
    listADTMutable.addFront(15);
    listADTMutable.addBack(10);
    listADTMutable.add(2,35);
    listADTMutable.remove(35);

    //Get immutable version of mutable list

    //performs all operations supported by


  }

  /**
   * Checks if the immutable version contains the same content as that of mutable.
   */
  @Test
  public void testGetImmutableSameContent() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertNotEquals(immutable, mutable);
    assertEquals(immutable.toString(), mutable.toString());
    for (int i = 0; i < mutable.getSize(); i++) {
      assertEquals(immutable.get(i), mutable.get(i));
    }
  }

  /**
   * Checks if the immutable version cannot be modified through addFront operation.
   */
  @Test(expected = UnsupportedOperationException.class)
  public void testGetImmutableAddFront() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertNotEquals(immutable, mutable);
    assertEquals(immutable.toString(), mutable.toString());
    immutable.addFront(1);
  }

  /**
   * Checks if the immutable version cannot be modified through addBack operation.
   */
  @Test(expected = UnsupportedOperationException.class)
  public void testGetImmutableAddBack() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    immutable.addBack(1);
  }

  /**
   * Checks if the immutable version cannot be modified through add operation.
   */
  @Test(expected = UnsupportedOperationException.class)
  public void testGetImmutableAdd() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    immutable.add(1, 23);
  }

  /**
   * Checks if the immutable version cannot be modified through remove operation.
   */
  @Test(expected = UnsupportedOperationException.class)
  public void testGetImmutableRemove() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    immutable.remove(5);
  }

  /**
   * Checks if the immutable version returns correct size.
   */
  @Test
  public void testImmutableGetSize() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    assertEquals(4, immutable.getSize());
  }

  /**
   * Checks if the immutable version returns value for get method.
   */
  @Test
  public void testImmutableGet() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    assertEquals(new Integer(10), immutable.get(1));
  }

  /**
   * Checks if the immutable version returns exception for invalid index in get method.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testImmutableGetInvalid1() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    immutable.get(10);
  }

  /**
   * Checks if the immutable version returns exception for invalid index in get method.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testImmutableGetInvalid2() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertNotEquals(immutable, mutable);
    immutable.get(-10);
  }

  /**
   * Checks if the immutable version works correctly for map method. The original map of integer has
   * been converted to string and been asserted for each value of list in Integer to value in
   * String. String immutable version is also checked for immutability.
   */
  @Test
  public void testImmutableMap() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertNotEquals(immutable, mutable);
    assertEquals(immutable.toString(), mutable.toString());
    ListADT<String> immutableStringMap = immutable.map(num -> Integer.toString(num));
    for (int i = 0; i < immutableStringMap.getSize(); i++) {
      assertEquals(immutableStringMap.get(i), Integer.toString(immutable.get(i)));
    }

    //checks if the returned new immutable string version is not allowing add operation.
    try {
      immutableStringMap.addFront("30");
    } catch (UnsupportedOperationException e) {
      assertEquals(immutableStringMap.toString(), immutable.toString());
    }

    //checks if the returned new immutable string version is not allowing add operation.
    try {
      immutableStringMap.addBack("70");
    } catch (UnsupportedOperationException e) {
      assertEquals(immutableStringMap.toString(), immutable.toString());
    }
    //checks if the returned new immutable string version is not allowing add operation.
    try {
      immutableStringMap.add(immutableStringMap.getSize() - 1, "13");
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), immutableStringMap.toString());
    }

    //checks if the returned new immutable string version is not allowing remove operation.
    try {
      immutableStringMap.remove("10");
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), immutableStringMap.toString());
    }

  }

  /**
   * Checks if the immutable list implementation returns mutable version of itself. If mutable
   * operations are successfully made and no values in immutable list gets changed in that process.
   */
  @Test
  public void testGetMutable() {
    ImmutableList<Integer> immutable = (ImmutableList) mutable.getImmutableList();
    MutableList<Integer> newMutable = (MutableList) immutable.getMutableList();
    assertNotEquals(newMutable, immutable);
    assertEquals(immutable.toString(), newMutable.toString());
    for (int i = 0; i < newMutable.getSize(); i++) {
      assertEquals(immutable.get(i), newMutable.get(i));
    }
    //checks if mutation is working correctly
    newMutable.remove(20);
    assertNotEquals(immutable.toString(), newMutable.toString());
    assertNotEquals(immutable.getSize(), newMutable.getSize());
    newMutable.add(3, 30);
    assertNotEquals(immutable.toString(), newMutable.toString());
    newMutable.addFront(20);
    assertNotEquals(immutable.toString(), newMutable.toString());
    assertNotEquals(immutable.getSize(), newMutable.getSize());
    newMutable.addBack(100);
    assertNotEquals(immutable.toString(), newMutable.toString());
    assertNotEquals(immutable.getSize(), newMutable.getSize());

    //fetches immutable version from the newMutable object
    ImmutableList<Integer> newImmutable = (ImmutableList) newMutable.getImmutableList();
    assertNotEquals(newImmutable, newMutable);
    assertEquals(immutable.toString(), newMutable.toString());
    for (int i = 0; i < newMutable.getSize(); i++) {
      assertEquals(newImmutable.get(i), newMutable.get(i));
    }

    //checks if the returned new immutable version is not allowing add operation.
    try {
      newImmutable.addFront(70);
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), newMutable.toString());
    }

    //checks if the returned new immutable version is not allowing add operation.
    try {
      newImmutable.addBack(70);
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), newMutable.toString());
    }
    //checks if the returned new immutable version is not allowing add operation.
    try {
      newImmutable.add(newImmutable.getSize() - 1, 16);
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), newMutable.toString());
    }

    //checks if the returned new immutable version is not allowing remove operation.
    try {
      newImmutable.remove(10);
    } catch (UnsupportedOperationException e) {
      assertEquals(immutable.toString(), newMutable.toString());
    }

  }

  /**
   * Test for toString implementation of Immutable list.
   */
  @Test
  public void testToString() {
    ListADT<Integer> immutable = mutable.getImmutableList();
    assertEquals(immutable.toString(), mutable.toString());
    assertEquals("(5 10 15 20)", immutable.toString());
    assertEquals(immutable.getSize(), immutable.getSize());
  }


}
