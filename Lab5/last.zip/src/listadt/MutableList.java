package listadt;

/**
 *
 * @param <T>
 */
public interface MutableList<T> extends ListADT<T>{
  /**
   * Returns an instance of Immutable version of a list. This list should be a read-only list
   * containing the same value as itself. The data inside the list can be mutable but not the entire
   * list which means any modifications such as add, remove on the new list cannot be made.
   *
   * @return immutable list containing generic data.
   */
  <R> ListADT<R> getImmutableList();
}
