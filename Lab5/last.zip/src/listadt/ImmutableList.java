package listadt;

/**
 *
 * @param <T>
 */
public interface ImmutableList<T> extends ListADT<T> {
  /**
   * Returns the list representation which is the Mutable version of itself. The implementation
   * should enforce no change in the original list if any operation is performed on this newly
   * returned mutable version of the list.
   */
  <R> ListADT<R> getMutableList();
}
