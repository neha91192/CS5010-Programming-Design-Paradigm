package howtoinvestfordummies.model;

import java.util.Map;

public interface IPersistenceStrategy {

  void save(InvestmentStrategies model, String name);

  Map<String, IPortfolio> restore(String name);
}