package howtoinvestfordummies.model;

public enum PortfolioType {
  SIMPLE("SIMPLE"), RECURRING("RECURRING");
  String value;

  PortfolioType(String value) {
    this.value = value;
  }
}
