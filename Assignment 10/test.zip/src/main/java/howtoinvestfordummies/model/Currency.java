package howtoinvestfordummies.model;

/**
 * Represents enumeration for currency.
 */
public enum Currency {
  USD, EURO, INR
}
