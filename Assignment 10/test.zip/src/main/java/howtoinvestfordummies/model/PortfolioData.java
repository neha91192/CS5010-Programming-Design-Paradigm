package howtoinvestfordummies.model;

import com.fasterxml.jackson.annotation.JsonSetter;

import java.util.Date;

public class PortfolioData {
  /**
   * Unique name of this portfolio in string.
   */
  private String portfolioName;
  /**
   * Represents type of portfolio.
   */
  private PortfolioType type;
  private int frequencyValue;
  private Date transactionStartDate;
  private Date transactionEndDate;
  public String getPortfolioName() {
    return portfolioName;
  }
  public PortfolioData(String portfolioName, PortfolioType type, int frequencyValue,
                       Date transactionStartDate, Date transactionEndDate){
    this.portfolioName = portfolioName;
    this.frequencyValue = frequencyValue;
    this.transactionStartDate = transactionStartDate;
    this.transactionEndDate = transactionEndDate;
    this.type = type;
  }

  public PortfolioType getType() {
    return type;
  }
  public int getFrequencyValue() {
    return frequencyValue;
  }
  public Date getTransactionStartDate() {
    return transactionStartDate;
  }
  public Date getTransactionEndDate() {
    return transactionEndDate;
  }
}
