package howtoinvestfordummies.model;

public interface Persistable {
  void save(String name);

  void restore(String name);
}
