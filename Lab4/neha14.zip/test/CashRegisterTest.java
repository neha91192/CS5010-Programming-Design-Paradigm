import org.junit.Before;
import org.junit.Test;

import cs5010.register.CashRegister;
import cs5010.register.Denomination;
import cs5010.register.InsufficientCashException;
import cs5010.register.SimpleRegister;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Test class for {@link cs5010.register.CashRegister}.
 */
public class CashRegisterTest {

  /**
   * Register to hold some initial values.
   */
  private CashRegister cashRegister1;
  /**
   * Contains log after each immediate operation.
   */
  private StringBuilder log;

  /**
   * Register to hold empty values.
   */
  private CashRegister cashRegister2;

  /**
   * Register to hold empty values.
   */
  private CashRegister cashRegister3;

  /**
   * Initialises cashRegister object instance.
   */
  @Before
  public void setUp() {
    cashRegister1 = new SimpleRegister();
    cashRegister2 = new SimpleRegister();
    cashRegister3 = new SimpleRegister();
    log = new StringBuilder();

  }

  /**
   * Test to add penny success.
   */
  @Test
  public void testAddPenniesSuccess() {
    cashRegister1.addPennies(0);
    int expected = cashRegister1.getContents().get(Denomination.PENNY.getValue());
    assertEquals(expected, 0);

    cashRegister1.addPennies(2);
    expected = cashRegister1.getContents().get(Denomination.PENNY.getValue());
    assertEquals(expected, 2);

    cashRegister1.addPennies(6);
    expected = cashRegister1.getContents().get(Denomination.PENNY.getValue());
    assertEquals(expected, 8);

    cashRegister1.addPennies(20);
    expected = cashRegister1.getContents().get(Denomination.PENNY.getValue());
    assertEquals(expected, 28);

    cashRegister1.addPennies(0);
    expected = cashRegister1.getContents().get(Denomination.PENNY.getValue());
    assertEquals(expected, 28);

  }

  /**
   * Test to add penny failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddPenniesFailure() {
    cashRegister1.addPennies(-2);
  }

  /**
   * Test to add nickel success.
   */
  @Test
  public void testAddNickelsSuccess() {
    cashRegister1.addNickels(0);
    int expected = cashRegister1.getContents().get(Denomination.NICKLE.getValue());
    assertEquals(expected, 0);

    cashRegister1.addNickels(2);
    expected = cashRegister1.getContents().get(Denomination.NICKLE.getValue());
    assertEquals(expected, 2);

    cashRegister1.addNickels(6);
    expected = cashRegister1.getContents().get(Denomination.NICKLE.getValue());
    assertEquals(expected, 8);

    cashRegister1.addNickels(20);
    expected = cashRegister1.getContents().get(Denomination.NICKLE.getValue());
    assertEquals(expected, 28);

    cashRegister1.addNickels(0);
    expected = cashRegister1.getContents().get(Denomination.NICKLE.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add Nickels.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddNickelsFailure() {
    cashRegister1.addNickels(-13323);
  }

  /**
   * Test to add dime success.
   */
  @Test
  public void testAddDimesSuccess() {
    cashRegister1.addDimes(0);
    int expected = cashRegister1.getContents().get(Denomination.DIME.getValue());
    assertEquals(expected, 0);

    cashRegister1.addDimes(2);
    expected = cashRegister1.getContents().get(Denomination.DIME.getValue());
    assertEquals(expected, 2);

    cashRegister1.addDimes(6);
    expected = cashRegister1.getContents().get(Denomination.DIME.getValue());
    assertEquals(expected, 8);

    cashRegister1.addDimes(20);
    expected = cashRegister1.getContents().get(Denomination.DIME.getValue());
    assertEquals(expected, 28);

    cashRegister1.addDimes(0);
    expected = cashRegister1.getContents().get(Denomination.DIME.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add dime failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddDimesFailure() {
    cashRegister1.addDimes(-112);
  }

  /**
   * Test to add quarter success.
   */
  @Test
  public void testAddQuartersSuccess() {
    cashRegister1.addQuarters(0);
    int expected = cashRegister1.getContents().get(Denomination.QUARTER.getValue());
    assertEquals(expected, 0);

    cashRegister1.addQuarters(2);
    expected = cashRegister1.getContents().get(Denomination.QUARTER.getValue());
    assertEquals(expected, 2);

    cashRegister1.addQuarters(6);
    expected = cashRegister1.getContents().get(Denomination.QUARTER.getValue());
    assertEquals(expected, 8);

    cashRegister1.addQuarters(20);
    expected = cashRegister1.getContents().get(Denomination.QUARTER.getValue());
    assertEquals(expected, 28);

    cashRegister1.addQuarters(0);
    expected = cashRegister1.getContents().get(Denomination.QUARTER.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add Quarter failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddQuartersFailure() {
    cashRegister1.addQuarters(-12);
  }

  /**
   * Test to add ones success.
   */
  @Test
  public void testAddOnesSuccess() {
    cashRegister1.addOnes(0);
    int expected = cashRegister1.getContents().get(Denomination.ONE.getValue());
    assertEquals(expected, 0);

    cashRegister1.addOnes(2);
    expected = cashRegister1.getContents().get(Denomination.ONE.getValue());
    assertEquals(expected, 2);

    cashRegister1.addOnes(6);
    expected = cashRegister1.getContents().get(Denomination.ONE.getValue());
    assertEquals(expected, 8);

    cashRegister1.addOnes(20);
    expected = cashRegister1.getContents().get(Denomination.ONE.getValue());
    assertEquals(expected, 28);

    cashRegister1.addOnes(0);
    expected = cashRegister1.getContents().get(Denomination.ONE.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add ones failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddOnesFailure() {
    cashRegister1.addOnes(-1);
  }

  /**
   * Test to add fives success.
   */
  @Test
  public void testAddFivesSuccess() {
    cashRegister1.addFives(0);
    int expected = cashRegister1.getContents().get(Denomination.FIVE.getValue());
    assertEquals(expected, 0);

    cashRegister1.addFives(2);
    expected = cashRegister1.getContents().get(Denomination.FIVE.getValue());
    assertEquals(expected, 2);

    cashRegister1.addFives(6);
    expected = cashRegister1.getContents().get(Denomination.FIVE.getValue());
    assertEquals(expected, 8);

    cashRegister1.addFives(20);
    expected = cashRegister1.getContents().get(Denomination.FIVE.getValue());
    assertEquals(expected, 28);

    cashRegister1.addFives(0);
    expected = cashRegister1.getContents().get(Denomination.FIVE.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add five failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddFivesFailure() {
    cashRegister1.addFives(-7);
  }

  /**
   * Test to add tens success.
   */
  @Test
  public void testAddTensSuccess() {
    cashRegister1.addTens(0);
    int expected = cashRegister1.getContents().get(Denomination.TEN.getValue());
    assertEquals(expected, 0);

    cashRegister1.addTens(2);
    expected = cashRegister1.getContents().get(Denomination.TEN.getValue());
    assertEquals(expected, 2);

    cashRegister1.addTens(6);
    expected = cashRegister1.getContents().get(Denomination.TEN.getValue());
    assertEquals(expected, 8);

    cashRegister1.addTens(20);
    expected = cashRegister1.getContents().get(Denomination.TEN.getValue());
    assertEquals(expected, 28);

    cashRegister1.addTens(0);
    expected = cashRegister1.getContents().get(Denomination.TEN.getValue());
    assertEquals(expected, 28);
  }

  /**
   * Test to add tens failure.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAddTensFailure() {
    cashRegister1.addTens(-2);
  }

  /**
   * Test to withdraw success when nothing is added.
   */
  @Test
  public void testWithdrawSuccess1() {
    try {
      cashRegister2.withdraw(0, 0);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when nothing is added.
   */
  @Test
  public void testWithdrawSuccess2() {
    try {
      cashRegister2.addOnes(1);
      log.append("Deposit: 1.00\n");
      cashRegister2.addPennies(1);
      log.append("Deposit: 0.01\n");
      cashRegister2.withdraw(1, 1);
      log.append("Withdraw: 1.01");
      int actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(actual, 0);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(actual, 0);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when amount is multiple of first denomination.
   */
  @Test
  public void testWithdrawSuccess3() {
    try {
      cashRegister2.addTens(2);
      log.append("Deposit: 20.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(2);
      log.append("Deposit: 2.00\n");
      cashRegister2.withdraw(20, 0);
      log.append("Withdraw: 20.00");
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(2, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(2, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when amount is multiple of first denomination.
   */
  @Test
  public void testWithdrawSuccess4() {
    try {
      cashRegister2.addTens(4);
      log.append("Deposit: 40.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(2);
      log.append("Deposit: 2.00\n");
      cashRegister2.withdraw(41, 0);
      log.append("Withdraw: 41.00");
      int expected = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(expected, 2);
      expected = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(expected, 1);
      expected = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(expected, 0);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when amount is used up entirely.
   */
  @Test
  public void testWithdrawSuccess5() {
    try {
      cashRegister2.addTens(4);
      log.append("Deposit: 40.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(2);
      log.append("Deposit: 2.00\n");
      cashRegister2.withdraw(52, 0);
      log.append("Withdraw: 52.00");
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when amount is less than first highest denominator for dollar.
   */
  @Test
  public void testWithdrawSuccess6() {
    try {
      cashRegister2.addTens(4);
      log.append("Deposit: 40.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(3);
      log.append("Deposit: 3.00\n");
      cashRegister2.withdraw(8, 0);
      log.append("Withdraw: 8.00");
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(4, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(1, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Test to withdraw success when all the denominator is used.
   */
  @Test
  public void testWithdrawSuccess7() {
    try {
      cashRegister2.addTens(4);
      log.append("Deposit: 40.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(3);
      log.append("Deposit: 3.00\n");
      cashRegister2.withdraw(16, 0);
      log.append("Withdraw: 16.00");
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(3, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(1, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(2, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Cases related to both dollars and cents.
   */
  @Test
  public void testWithdrawPositive8() {
    try {
      cashRegister2.addTens(4);
      log.append("Deposit: 40.00\n");
      cashRegister2.addFives(2);
      log.append("Deposit: 10.00\n");
      cashRegister2.addOnes(3);
      log.append("Deposit: 3.00\n");
      cashRegister2.addQuarters(8);
      log.append("Deposit: 2.00\n");
      cashRegister2.addDimes(20);
      log.append("Deposit: 2.00\n");
      cashRegister2.addNickels(40);
      log.append("Deposit: 2.00\n");
      cashRegister2.addPennies(400);
      log.append("Deposit: 4.00\n");
      cashRegister2.withdraw(52, 400);
      log.append("Withdraw: 56.00");
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(1, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(40, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(400, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    } catch (InsufficientCashException e) {
      fail("Error");
    }
  }

  /**
   * Cases when there is withdrawal failure. Nothing has been added and trying to withdraw.
   */
  @Test
  public void testWithdrawFailure1() {
    try {
      cashRegister2.withdraw(10, 50);
      fail("Error");
    } catch (InsufficientCashException e) {
      int actual = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(0, actual);
      actual = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(0, actual);
      assertEquals(log.toString(), cashRegister2.getAuditLog());
    }

  }

  /**
   * Cases when there is withdrawal failure.
   */
  @Test
  public void testWithdrawFailure2() {
    try {
      cashRegister3.withdraw(200, 50);
      fail("Error");
    } catch (InsufficientCashException e) {
      System.out.println(cashRegister3.getAuditLog());
    }

  }

  /**
   * Cases when there is withdrawal failure.
   */
  @Test
  public void testWithdrawFailure3() {
    try {
      cashRegister3.withdraw(2, 10000);
      fail("Error");
    } catch (InsufficientCashException e) {
      System.out.println(cashRegister3.getAuditLog());
    }

  }

  /**
   * Test to withdraw failure when there is no sufficient dollars left.
   */
  @Test
  public void testWithdrawFailure4() {
    try {
      cashRegister2.addTens(2);
      cashRegister2.addFives(2);
      cashRegister2.addOnes(2);
      cashRegister2.withdraw(23, 0);
      fail("Error");
    } catch (InsufficientCashException e) {
      int expected = cashRegister2.getContents().get(Denomination.TEN.getValue());
      assertEquals(expected, 2);
      expected = cashRegister2.getContents().get(Denomination.FIVE.getValue());
      assertEquals(expected, 2);
      expected = cashRegister2.getContents().get(Denomination.ONE.getValue());
      assertEquals(expected, 2);
      expected = cashRegister2.getContents().get(Denomination.QUARTER.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.DIME.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.NICKLE.getValue());
      assertEquals(expected, 0);
      expected = cashRegister2.getContents().get(Denomination.PENNY.getValue());
      assertEquals(expected, 0);
    }

  }

  /**
   * Cases when there is Illegal argument provided.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testWithdrawNegativeNumber1() {
    try {
      cashRegister1.withdraw(-20, -50);
    } catch (InsufficientCashException e) {
      System.out.println(cashRegister1.getAuditLog());
    }

  }

  /**
   * Cases when there is Illegal argument provided.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testWithdrawNegativeNumber2() {
    try {
      cashRegister1.withdraw(-1, 90);
      fail("Error");
    } catch (InsufficientCashException e) {
      System.out.println(cashRegister1.getAuditLog());
    }

  }

//  /**
//   * Cases when there is Illegal argument provided.
//   */
//  @Test
//  public void testGetAuditLog() {
//    System.out.println(cashRegister1.getAuditLog());
//  }
//
//  /**
//   * Cases when there is Illegal argument provided.
//   */
//  @Test
//  public void testGetContentEmpty() {
//    System.out.println(cashRegister1.getAuditLog());
//  }
//
//  /**
//   * Cases when there is Illegal argument provided.
//   */
//  @Test
//  public void testGetContentAllPresent() {
//    System.out.println(cashRegister1.getAuditLog());
//  }

}
