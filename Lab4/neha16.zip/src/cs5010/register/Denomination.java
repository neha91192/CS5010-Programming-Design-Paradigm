package cs5010.register;

/**
 * Represents coin denomination class.
 */
public enum Denomination {
  TEN(1000, "Dollar"), FIVE(500, "Dollar"), ONE(100, "Dollar"), QUARTER(25, "Cents"),
  DIME(10, "Cents"), NICKLE(5, "Cents"), PENNY(1, "Cents");

  /**
   * Value of the denomination in cents.
   */
  private final Integer value;
  /**
   * Value of the denomination in cents.
   */
  private final String type;

  /**
   * Constructor which sets denomination value.
   */
  Denomination(Integer value, String type) {
    this.value = value;
    this.type = type;
  }

  /**
   * Returns value of the calling denomination.
   *
   * @return value of the denomination represented in cents in Integer.
   */
  public Integer getValue() {
    return this.value;
  }

  /**
   * Returns type of the calling denomination.
   *
   * @return type of the denomination represented in cents in Integer.
   */
  public String getType() {
    return this.type;
  }

}
