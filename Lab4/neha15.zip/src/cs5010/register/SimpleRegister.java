package cs5010.register;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Represents the implementation class for {@link CashRegister}.
 */
public class SimpleRegister implements CashRegister {

  /**
   * Represents data structure to store denomination values (in cents) as keys and corresponding
   * number of coins that are available for the given denomination.
   */
  private Map<Integer, Integer> cashRegister;
  /**
   * Instance to store complete log.
   */
  private StringBuilder transactionLog;
  /**
   * Constant for Deposit transaction type.
   */
  private static final String DEPOSIT = "Deposit";
  /**
   * Constant for Withdraw transaction type.
   */
  private static final String WITHDRAW = "Withdraw";

  /**
   * Represents constructor of this class responsible for creating cashRegister instance. It
   * initialises cashRegister as TreeMap which essentially stores its value in the natural ordering
   * of keys. To allow storage of key value pairs in decreasing order, TreeMap is initialized with
   * the Collections.reverseOrder() parameter to set is ordering to decreasing order. It then
   * inserts all types of denomination with the default value of 0 and creates an instance of
   * transactionLog.
   */
  public SimpleRegister() {
    cashRegister = new TreeMap<>(Collections.reverseOrder());
    for (Denomination value : Denomination.values()) {
      cashRegister.put(value.getValue(), 0);
    }
    transactionLog = new StringBuilder();
  }

  /**
   * Adds pennies to the register.
   *
   * @param num number of pennies to be added.
   */
  @Override
  public void addPennies(int num) {
    addValue(Denomination.PENNY, num);
  }

  /**
   * Adds nickels to the register.
   *
   * @param num number of nickels to be added.
   */
  @Override
  public void addNickels(int num) {
    addValue(Denomination.NICKLE, num);
  }

  /**
   * Adds dimes to the register.
   *
   * @param num number of dimes to be added.
   */
  @Override
  public void addDimes(int num) {
    addValue(Denomination.DIME, num);
  }

  /**
   * Adds quarters to the register.
   *
   * @param num number of quarters to be added.
   */
  @Override
  public void addQuarters(int num) {
    addValue(Denomination.QUARTER, num);
  }

  /**
   * Adds ones to the register.
   *
   * @param num number of ones to be added.
   */
  @Override
  public void addOnes(int num) {
    addValue(Denomination.ONE, num);
  }

  /**
   * Adds fives to the register.
   *
   * @param num fives of ones to be added.
   */
  @Override
  public void addFives(int num) {
    addValue(Denomination.FIVE, num);
  }

  /**
   * Adds tens to the register.
   *
   * @param num tens of ones to be added.
   */
  @Override
  public void addTens(int num) {
    addValue(Denomination.TEN, num);
  }

  /**
   * <p>Withdraws amount given in dollar and cents. It first creates a new register instance on
   * which operation needs to be performed. After that, it checks if the nothing has to be withdrawn
   * and in that case, returns the instance immediately. Further, it performs withdrawal operation
   * in case of denominations related to dollars. If there are enough dollars for the given dollar
   * amount, it proceeds by finding if cents can be withdrawn as per the current status of the
   * register. If both the withdrawal operation is successful, it logs the transaction, updates the
   * actual register and returns the newly created instance.</p>
   * <p>If any of the withdrawal operation is unsuccessful, it throws {@link
   * InsufficientCashException} with appropriate message. In case negative inputs are provided, it
   * throws {@link IllegalArgumentException}</p>
   *
   * @param dollars the dollar amount to be withdrawn.
   * @param cents   the cent amount to be withdrawn.
   * @return map containing key as denominations and value as total number of coins remaining.
   */
  @Override
  public Map<Integer, Integer> withdraw(int dollars, int cents) throws InsufficientCashException {
    Map<Integer, Integer> register = new TreeMap<>(cashRegister);
    Map<Integer, Integer> withdrawalAmount = new HashMap<>();
    if (dollars == 0 && cents == 0) {
      return register;
    }
    if (!withdrawDollar(register, dollars * 100, withdrawalAmount)) {
      throw new InsufficientCashException("Cannot perform withdraw operation as there is no "
              + "sufficient dollar notes");
    }
    if (!withdrawCents(register, cents, withdrawalAmount)) {
      throw new InsufficientCashException("Cannot perform withdraw operation as there is "
              + "no sufficient cents");
    }
    writeAuditLog(WITHDRAW, dollars * 100 + cents);
    cashRegister = register;
    return withdrawalAmount;
  }


  /**
   * Fetches contents of the cashRegister. It returns a duplicate instance of the register to
   * disallow any unauthorized deposit/withdraw operation on actual cash register.
   *
   * @return cash register of type map.
   */
  @Override
  public Map<Integer, Integer> getContents() {
    return new TreeMap<>(cashRegister);
  }

  /**
   * Checks for all the denominations related to dollars and withdraws the given amount. If amount
   * cannot be withdrawn, it returns false otherwise true.
   *
   * @param register representing cash storage of this register.
   * @param amount   in cents that needs to be withdrawn.
   * @return true in case withdrawal operation is successful, otherwise false.
   */
  private boolean withdrawDollar(Map<Integer, Integer> register, int amount, Map<Integer,
          Integer> withdrawalAmount) {
    if (amount < 0) {
      throw new IllegalArgumentException("Values cannot be negative");
    }
    int count = 0;
    for (Integer denomination : cashRegister.keySet()) {
      if (denomination >= Denomination.ONE.getValue()) {
        int noOfCoins = register.get(denomination);
        while (amount >= denomination && noOfCoins > 0) {
          amount = amount - denomination;
          noOfCoins--;
          count++;
        }
        register.put(denomination, noOfCoins);
        if(count>0){
          withdrawalAmount.put(denomination, count);
          count=0;
        }
        if (amount == 0) {
          return true;
        }
      }
    }
    return (amount < 0);
  }

  /**
   * Checks for all the denominations related to cents and withdraws the given amount. If amount
   * cannot be withdrawn, it returns false otherwise true.
   *
   * @param register representing cash storage of this register.
   * @param amount   in cents that needs to be withdrawn.
   * @return true in case withdrawal operation is successful, otherwise false.
   */
  private boolean withdrawCents(Map<Integer, Integer> register, int amount, Map<Integer,
          Integer> withdrawalAmount) {
    if (amount < 0) {
      throw new IllegalArgumentException("Values cannot be negative");
    }
    int count = 0;
    for (Integer denomination : cashRegister.keySet()) {
      if (denomination < Denomination.ONE.getValue()) {
        int noOfCoins = register.get(denomination);
        while (amount >= denomination && noOfCoins > 0) {
          amount = amount - denomination;
          noOfCoins--;
          count++;
        }
        register.put(denomination, noOfCoins);
        if(count>0){
          withdrawalAmount.put(denomination, count);
          count = 0;
        }
        if (amount == 0) {
          return true;
        }
      }
    }
    return (amount < 0);
  }

  /**
   * Creates transaction log for a given transaction type and amount and appends it to the common
   * transaction log.
   *
   * @param transaction describing whether transaction is Deposit or Withdraw in String.
   * @param amount      of transaction represented in int.
   */
  private void writeAuditLog(String transaction, int amount) {
    String log = transaction + ": " + convertCentsToDollarFormat(amount);
    if (transactionLog.toString().equals("")) {
      transactionLog.append(log);
    } else {
      transactionLog.append('\n');
      transactionLog.append(log);
    }

  }

  /**
   * Formats the value in cents to a proper String format containing dollar and cents value (up to 2
   * decimals).
   *
   * @param cents total amount of value in int that needs to be formatted.
   * @return formatted representation of string.
   */
  private String convertCentsToDollarFormat(int cents) {
    Integer dollarValue = cents / 100;
    Integer centValue = cents % 100;
    return dollarValue.toString() + "." + String.format("%02d", centValue);
  }


  /**
   * Inserts entry in the cash register as per given denomination and number of coins need to be
   * added.
   *
   * @param denomination of type Denomination enumeration.
   * @param num          represents number of coins need to be added in int for a given
   *                     denomination.
   */
  private void addValue(Denomination denomination, int num) {
    if (num < 0) {
      throw new IllegalArgumentException("Values cannot be negative");
    }
    int count = cashRegister.get(denomination.getValue());
    cashRegister.put(denomination.getValue(), count + num);
    writeAuditLog(DEPOSIT, num * denomination.getValue());

  }

  /**
   * Returns all the transaction log in String. A class level StringBuffer is maintained to keep
   * track of all the withdrawal and delete related logs. Refer {@link CashRegister#getAuditLog()}
   * for more details.
   */
  @Override
  public String getAuditLog() {
    return this.transactionLog.toString();
  }
}
