package questionaire;

/**
 *
 */
public abstract class AbstractQuestion implements IQuestion {
  /**
   * This represents complete question text.
   */
  final String text;
  /**
   * Represents correctAnswer of this question object. It can be correct or incorrect depending upon
   * the what the standard correctAnswer is of the same question. Also, any invalid correctAnswer
   * format stored in this object will be regarded as incorrect.
   */
  final String correctAnswer;

  /**
   *
   */
  String attemptedAnswer;

  /**
   *
   * @param text
   */
  public AbstractQuestion(String text, String correctAnswer) throws IllegalArgumentException {
    this.text = text;
    if (this.validateAnswerFormat(correctAnswer)) {
      this.correctAnswer = correctAnswer;
    } else {
      this.correctAnswer = "";
    }
  }

  /**
   *
   * @param text
   */
  public AbstractQuestion(String text, String correctAnswer, String attemptedAnswer) {
    this.text = text;
    this.correctAnswer = correctAnswer;
    this.attemptedAnswer = attemptedAnswer;
  }

  /**
   *
   * @param answer
   * @return
   */
  @Override
  public abstract IQuestion enterAnswer(String answer);

  /**
   * Not enforcing other question classes to implement this method. Some questions are not
   * answerable or cannot be evaluated.
   */
  @Override
  public String evaluate() {
    return "";
  }

  /**
   *
   * @param answer
   * @return
   */
  protected abstract boolean validateAnswerFormat(String answer);


  /**
   * Returns value of question text.
   *
   * @return text of type String.
   */
  public String getQuestionText() {
    return this.text;
  }

}
