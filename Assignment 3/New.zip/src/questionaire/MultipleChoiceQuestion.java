package questionaire;

/**
 * Multiple Choice type questions are of type Multiple Answers.
 */
public class MultipleChoiceQuestion extends AbstractQuestion {

  /**
   *
   */
  private String[] options;
  private static final Integer OPTIONS_MAX_LENGTH = 8;
  private static final Integer OPTIONS_MIN_LENGTH = 3;
  private static final String DELIMITER = " ";

  /**
   *
   * @param text
   * @param answer
   * @param options
   */
  public MultipleChoiceQuestion(String text, String[] options, String answer)
          throws IllegalArgumentException{
    super(text, answer);
    if (isAnswerValidOption(options.length)) {
      setOptions(options);
    }
  }

  /**
   *
   * @param text
   * @param answer
   * @param options
   */
  private MultipleChoiceQuestion(String text, String[] options, String answer,
                                 String correctAnswer) {
    super(text, answer, correctAnswer);
    this.options = options;
  }

  /**
   *
   * @param answer
   * @return
   * @throws IllegalArgumentException
   */
  @Override
  public boolean validateAnswerFormat(String answer) throws IllegalArgumentException {
    String[] answerBuffer = answer.split(DELIMITER);
    if (answerBuffer.length != 1) {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_MULTIPLE_ANSWER_MCQ);
    } else {
      try {
        Integer.parseInt(answerBuffer[0]);
      } catch (NumberFormatException e) {
        throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_ANSWER_NOT_AN_OPTION);
      }
    }
    return true;
  }

  /**
   *
   * @param options
   * @throws IllegalArgumentException
   */
  private void setOptions(String[] options) throws IllegalArgumentException {
    if (options.length < OPTIONS_MIN_LENGTH || options.length > OPTIONS_MAX_LENGTH) {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_OPTIONS_SIZE_MCQ);
    }
    this.options = options;
  }

  /**
   *
   * @return
   */
  private boolean isAnswerValidOption(Integer optionLength) throws IllegalArgumentException {
    if (Integer.parseInt(correctAnswer) < 1 || Integer.parseInt(correctAnswer) > optionLength) {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_ANSWER_NOT_AN_OPTION);
    }
    return true;
  }

  /**
   * Implements something similar to equals method. Compares user attempted question object with
   * that of standard question calling object. Evaluation returns "Correct" if text and correctAnswer
   * fields are same. For this type of question, correctAnswer can be case insensitive and so "Yes", "YES"
   * or "yes" would be regarded as the same.
   *
   * @return String of type {@link EvaluationResult#getValue()}
   */
  public String evaluate() {
    try{
      if (validateAnswerFormat(this.attemptedAnswer) && answersEqual()) {
        return EvaluationResult.CORRECT.name();
      }
      return EvaluationResult.INCORRECT.name();
    } catch (IllegalArgumentException e) {
      return EvaluationResult.INCORRECT.name();
    }
  }

  /**
   *
   */
  private boolean answersEqual() {
    return (Integer.parseInt(this.correctAnswer.trim())
            == Integer.parseInt(this.attemptedAnswer.trim()));
  }

  /**
   * Creates a new copy of question that user is attempting, while creating new object, it adds the
   * user correctAnswer value. Returns attempted question instance.
   *
   * @return object of type {@link IQuestion}
   */
  @Override
  public IQuestion enterAnswer(String userAnswer) {
    return new MultipleChoiceQuestion(this.text, this.options,
            this.correctAnswer, userAnswer);
  }


}
