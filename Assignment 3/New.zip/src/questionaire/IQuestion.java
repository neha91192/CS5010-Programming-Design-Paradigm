package questionaire;

/**
 *
 */
public interface IQuestion {
  /**
   *
   * @param answer
   * @return
   */
  IQuestion enterAnswer(String answer);

  /**
   *
   * @return
   */
  String evaluate();

  /**
   *
   * @return
   */
  String getQuestionText();
}
