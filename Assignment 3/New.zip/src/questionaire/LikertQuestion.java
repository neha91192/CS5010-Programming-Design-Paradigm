package questionaire;

/**
 *
 */
public class LikertQuestion extends AbstractQuestion {

  LikertScale[] options;
  private static final String DEFAULT_ANSWER = "";

  /**
   *
   * @param text
   */
  public LikertQuestion(String text) {
    super(text, DEFAULT_ANSWER);
    this.options = LikertScale.values();
  }

  /**
   *
   * @param text
   */
  private LikertQuestion(String text, String attemptedAnswer) {
    super(text, DEFAULT_ANSWER, attemptedAnswer);
    this.options = LikertScale.values();
  }

  @Override
  public boolean validateAnswerFormat(String answer) {
    try {
      Integer.parseInt(answer);
    } catch (NumberFormatException e) {
      return false;
    }
    return true;
  }
  /**
   *
   * @return
   */
  @Override
  public String evaluate() {
    if (validateAnswerFormat(this.attemptedAnswer) && answersEqual()) {
      return EvaluationResult.CORRECT.name();
    } else {
      return EvaluationResult.INCORRECT.name();
    }
  }

  /**
   * Creates a new copy of question that user is attempting, while creating new object, it overrides
   * the correctAnswer value with that of user's. Returns attempted question instance.
   *
   * @return object of type {@link IQuestion}
   */
  @Override
  public IQuestion enterAnswer(String userAnswer) {
    return new LikertQuestion(this.text, userAnswer);
  }

  private boolean answersEqual(){
    return LikertScale.contains(this.attemptedAnswer);
  }
}
