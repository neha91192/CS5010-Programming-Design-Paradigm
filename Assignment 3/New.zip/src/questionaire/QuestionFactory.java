package questionaire;

public class QuestionFactory {
  /**
   * 
   * @return
   */
  public IQuestion createInstance(IQuestion question){

    return null;
  }
}
