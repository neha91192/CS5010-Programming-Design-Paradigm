package questionaire;

public class Likert extends Question{

  LikertScale[] options;

  /**
   *
   * @param text
   */
  public Likert(Questionaire text) {
    super(text);
    this.options = LikertScale.values();
  }
}
