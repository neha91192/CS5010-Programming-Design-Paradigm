package questionaire;

/**
 *
 */
public class Question implements Questionaire {
  /**
   *
   */
  private String text;
  /**
   *
   */
  protected String correctAnswer;

  /**
   *
   * @param text
   */
  public Question(String text){
    this.text = text;
  }

  /**
   *
   * @param answer
   * @return
   */
  @Override
  public Questionaire setAnswer(String answer) {
    return null;
  }

  /**
   *
   * @return
   */
  @Override
  public String evaluate() {
    return null;
  }
}
