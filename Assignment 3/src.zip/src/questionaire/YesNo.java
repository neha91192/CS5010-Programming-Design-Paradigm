package questionaire;

public class YesNo extends Question{


  public YesNo(Questionaire text, String correctAnswer) throws IllegalArgumentException{
    super(text);
    if(correctAnswer.equals("Yes" )|| correctAnswer.equals("No")) {
      this.correctAnswer = correctAnswer;
    } else {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_CORRECT_ANSWER_YESNO);
    }
  }

}
