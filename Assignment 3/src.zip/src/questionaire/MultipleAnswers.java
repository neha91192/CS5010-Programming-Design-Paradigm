package questionaire;

public class MultipleAnswers extends Question{
  /**
   *
   */
  private String[] options;

  /**
   *
   * @param text
   * @param correctAnswer
   * @param options
   */
  public MultipleAnswers(Questionaire text, String correctAnswer, String[] options){
    super(text);

    if(options.length < 3 || options.length > 8) {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_OPTIONS_SIZE_MCQ);
    }

    for(int i=0; i< options.length; i++) {
      this.options[i] = options[i];
    }

    //check if the correct answer contains only number
    this.correctAnswer = correctAnswer;
  }
}
