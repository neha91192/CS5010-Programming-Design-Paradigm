package questionaire;

/**
 *  Multiple Choice type questions are of type Multiple Answers.
 */
public class MultipleChoice extends MultipleAnswers{

  /**
   *
   */
  private String[] options;

  /**
   *
   * @param text
   * @param correctAnswer
   * @param options
   */
  public MultipleChoice(Questionaire text, String correctAnswer, String[] options) {
    super(text, correctAnswer, options);

    if(correctAnswer.split("").length ==1) {
      //check if the correct answer contains only one number
      this.correctAnswer = correctAnswer;
    } else {
      throw new IllegalArgumentException(ExceptionMessageConstants.INVALID_CORRECT_ANSWER_MCQ);
    }

  }
}
