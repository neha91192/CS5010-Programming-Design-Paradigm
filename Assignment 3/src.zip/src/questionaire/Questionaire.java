package questionaire;

/**
 *
 */
public interface Questionaire {

  /**
   *
   * @param answer
   * @return
   */
  Questionaire setAnswer(String answer);

  /**
   *
   * @return
   */
  String evaluate();
}
