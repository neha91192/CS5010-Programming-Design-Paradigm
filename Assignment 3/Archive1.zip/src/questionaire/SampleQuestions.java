package questionaire;

/**
 * Constants class designated to keep set of Questions.
 */
public final class SampleQuestions {
  /**
   * Represents sample Question text.
   */
  public static final String QUESTION_1 = "Are you in Final Year?";
  /**
   * Represents sample Question text.
   */
  public static final String QUESTION_2 = "Is Sky Blue?";
  /**
   * Represents sample Question text.
   */
  public static final String QUESTION_3 = "Do you think if this course met requirements?";
  /**
   * Represents sample Question text.
   */
  public static final String QUESTION_4 = "Do you think if this session was helpful?";
  /**
   * Represents sample Question text.
   */
  public static final String QUESTION_5 = "Are you working in Summer?";
}

