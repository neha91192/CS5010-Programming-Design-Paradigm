package questionaire;

public class QuestionFactory {
  /**
   * 
   * @return
   */
  public IQuestion getInstance(){
    return null;
  }
}
