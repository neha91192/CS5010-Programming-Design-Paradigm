package questionaire;

/**
 *
 */
public interface IQuestionaire {

}
